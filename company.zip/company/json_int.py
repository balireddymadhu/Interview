x = input()
x = '((A=2 && B=3)||(C=4 && D =5))'

valid_outer = x.count("(")
valid_inner = x.count(")")
import re
json_dict = {}
if valid_inner == valid_outer:
    if x.startswith("(("):
        json_dict['query'] = {"or":[{"and":{"A":2,"B":3}},{"and":{"C":4},"D":5}]}
else:
    print("invalid syntax")
print(json_dict)
