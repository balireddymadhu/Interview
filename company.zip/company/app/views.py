from .models import Employee, Manger
from .serializer import MangerSerializer, EmployeeSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics


class EmployeeList(generics.ListAPIView):

    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer


class MangerList(generics.ListAPIView):

    queryset = Manger.objects.all()
    serializer_class = MangerSerializer
