from django.contrib import admin

from app.models import Manger, Employee

admin.site.register(Manger)
admin.site.register(Employee)

# Register your models here.
