from rest_framework import serializers

from app.models import Manger, Employee


class MangerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Manger
        fields = "__all__"


class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = "__all__"


