from django.db import models


class Manger(models.Model):
    manger_name = models.CharField(max_length=200,primary_key = True)
    designation = models.CharField(max_length=100)
    dob = models.DateField(blank=True)
    doj = models.DateField(blank=True,null=True)
    address = models.TextField(null=True, blank=True)
    habits = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.manger_name


class Employee(models.Model):
    manger_name = models.ForeignKey(Manger, on_delete=models.CASCADE)
    emp_name = models.CharField(max_length=150)
    designation = models.CharField(max_length=100)
    dob = models.DateField(blank=True)
    doj = models.DateField(blank=True,null=True)
    address = models.TextField(null=True, blank=True)
    habits = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.emp_name
